document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form');
    const mensajeError = document.querySelector('.mensaje-error');

    form.addEventListener('submit', async function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        try {
            const response = await fetch('/usuario', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                mostrarMensaje(data.mensaje || "Cambios guardados correctamente", false);
                form.reset();
            } else {
                mostrarMensaje(data.error || "Error al guardar los cambios", true);
            }
        } catch (error) {
            console.error('Error al enviar:', error);
            mostrarMensaje("Error de conexión con el servidor", true);
        }
    });

    function mostrarMensaje(texto, esError) {
        mensajeError.textContent = texto;

        if (esError) {
            mensajeError.classList.remove('hidden');
        } else {
            mensajeError.style.background = 'rgba(0, 128, 0, 0.1)';
            mensajeError.style.borderLeft = '5px solid #2ecc71';
            mensajeError.style.color = '#2ecc71';
            mensajeError.classList.remove('hidden');
        }

        // Ocultar mensaje después de 4 segundos
        setTimeout(() => {
            mensajeError.classList.add('hidden');
            // Restaurar estilo original si no es error
            if (!esError) {
                mensajeError.style.background = '';
                mensajeError.style.borderLeft = '';
                mensajeError.style.color = '';
            }
        }, 4000);
    }
	
	const imagenesPerfil = document.querySelectorAll(".imagen-perfil");

	// Obtener la imagen de perfil actual
	fetch("/usuario/imagenes")
	    .then(response => response.json())
	    .then(data => {
	        if (data.url) {
	            imagenesPerfil.forEach(img => {
	                img.src = data.url;
	            });
	        }
	    })
	    .catch(error => {
	        console.error('Error al obtener la imagen:', error);
	    });
});