package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ImagenUsuario {

    public static String obtenerImagenUsuario(String nombreUsuario) {
        if (nombreUsuario == null || nombreUsuario.isEmpty()) {
            return null;
        }

        try (Connection conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1/fabrica", "root", "");
             PreparedStatement pstmt = conexion.prepareStatement("SELECT imagen FROM usuarios WHERE usuario = ?")) {

            pstmt.setString(1, nombreUsuario);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String imagen = rs.getString("imagen");
                if (imagen != null && !imagen.isEmpty()) {
                    return "/" + imagen;
                } else {
                    return "/imagenes/default.png";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "/img/default.png";
    }
}
